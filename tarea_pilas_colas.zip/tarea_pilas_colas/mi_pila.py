from pasajero import Pasajero


class MiPila:
    """Pila (LIFO) hecha a mano sobre un arreglo de tamaño fijo.
    datos -> [fondo, ..., TOPE, None, None]
    TOPE  -> datos[cantidad - 1]  (el último que entró: el único que se ve y el único que sale)
    ⛔ Mismas prohibiciones que MiLista: sin append, pop, insert, remove, index,
       sort, reverse, copy, len(), in, slicing ni comprensiones.
    """

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad
        self.capacidad = capacidad
        self.cantidad = 0

    def apilar(self, pasajero):                      # ✅ resuelto + mejora (sin repetidos)
        if self.buscar(pasajero.numero) != -1:
            print(f"  ⚠ Ya existe el pasajero #{pasajero.numero}")
            return False
        if self.cantidad == self.capacidad:
            print("  ⚠ La pila está llena")
            return False
        self.datos[self.cantidad] = pasajero          # el nuevo queda encima: es el TOPE
        self.cantidad = self.cantidad + 1
        return True

    def listar(self):                                 # ✅ EJEMPLO: del TOPE al FONDO
        if self.cantidad == 0:
            print("  (pila vacía)")
            return
        for i in range(self.cantidad - 1, -1, -1):    # cantidad-1, ..., 1, 0  (hacia atrás)
            if i == self.cantidad - 1:
                print(f"  [{i}] {self.datos[i]}  ← TOPE")
            elif i == 0:
                print(f"  [{i}] {self.datos[i]}  ← FONDO")
            else:
                print(f"  [{i}] {self.datos[i]}")

    # ------- IMPLEMENTADOS · recorren SIEMPRE del tope al fondo -------
    def desapilar(self):
        """Saca el tope. Retorna el pasajero, o None si la pila está vacía."""
        if self.cantidad == 0:
            return None
        pasajero = self.datos[self.cantidad - 1]
        self.datos[self.cantidad - 1] = None          # no se corre nada
        self.cantidad = self.cantidad - 1
        return pasajero

    def ver_tope(self):
        """Retorna el tope sin sacarlo (None si está vacía)."""
        if self.cantidad == 0:
            return None
        return self.datos[self.cantidad - 1]

    def buscar(self, numero, mostrar_recorrido=False):
        """Búsqueda lineal del tope al fondo. Retorna la posición o -1.
        Con mostrar_recorrido=True imprime los pasajeros que va revisando."""
        for i in range(self.cantidad - 1, -1, -1):
            if mostrar_recorrido:
                if i == self.cantidad - 1:
                    print("  Revisó: ", end="")
                else:
                    print(" → ", end="")
                print(self.datos[i].nombre, end="")
            if self.datos[i].numero == numero:
                if mostrar_recorrido:
                    print()
                return i
        if mostrar_recorrido and self.cantidad > 0:
            print()
        return -1

    def modificar(self, numero, nuevo_destino, nuevo_asiento):
        pos = self.buscar(numero)
        if pos == -1:
            return False
        self.datos[pos].destino = nuevo_destino
        self.datos[pos].asiento = nuevo_asiento
        return True

    def eliminar_por_numero(self, numero):
        """No se puede sacar del medio: se desapila hacia una pila auxiliar
        hasta encontrarlo, se descarta y se vuelve a apilar lo de la auxiliar."""
        if self.buscar(numero) == -1:
            return False
        aux = MiPila(self.capacidad)
        while True:
            pasajero = self.desapilar()
            if pasajero.numero == numero:
                break                                 # este se descarta
            aux.apilar(pasajero)
        while aux.cantidad > 0:                       # devolver en el mismo orden
            self.apilar(aux.desapilar())
        return True

    def copiar(self):
        """Nueva pila; apila del fondo al tope para que el tope siga siendo el mismo."""
        nueva = MiPila(self.capacidad)
        for i in range(self.cantidad):                # 0 → cantidad-1
            nueva.apilar(self.datos[i])
        return nueva

    def longitud(self):
        return self.cantidad

    def esta_vacia(self):
        return self.cantidad == 0
