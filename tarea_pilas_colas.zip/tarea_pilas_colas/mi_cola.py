from pasajero import Pasajero


class MiCola:
    """Cola (FIFO) hecha a mano sobre un arreglo de tamaño fijo.
    datos  -> [FRENTE, ..., FINAL, None, None]
    FRENTE -> datos[0]             (el primero que llegó: el único que sale)
    FINAL  -> datos[cantidad - 1]  (los nuevos se ponen detrás de él)
    ⛔ Mismas prohibiciones que MiLista: sin append, pop, insert, remove, index,
       sort, reverse, copy, len(), in, slicing ni comprensiones.
    """

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad
        self.capacidad = capacidad
        self.cantidad = 0

    def encolar(self, pasajero):                     # ✅ resuelto + mejora (sin repetidos)
        if self.buscar(pasajero.numero) != -1:
            print(f"  ⚠ Ya existe el pasajero #{pasajero.numero}")
            return False
        if self.cantidad == self.capacidad:
            print("  ⚠ La cola está llena")
            return False
        self.datos[self.cantidad] = pasajero          # se pone a la fila por detrás
        self.cantidad = self.cantidad + 1
        return True

    def listar(self):                                 # ✅ EJEMPLO: del FRENTE al FINAL
        if self.cantidad == 0:
            print("  (cola vacía)")
            return
        for i in range(self.cantidad):                # 0, 1, ..., cantidad-1  (hacia adelante)
            if i == 0:
                print(f"  [{i}] {self.datos[i]}  ← FRENTE")
            elif i == self.cantidad - 1:
                print(f"  [{i}] {self.datos[i]}  ← FINAL")
            else:
                print(f"  [{i}] {self.datos[i]}")

    # ------- IMPLEMENTADOS · recorren SIEMPRE del frente al final -------
    def desencolar(self):
        """Saca el frente y corre todos a la izquierda. Retorna el pasajero o None."""
        if self.cantidad == 0:
            return None
        pasajero = self.datos[0]
        for i in range(self.cantidad - 1):
            self.datos[i] = self.datos[i + 1]
        self.datos[self.cantidad - 1] = None
        self.cantidad = self.cantidad - 1
        return pasajero

    def ver_frente(self):
        """Retorna el frente sin sacarlo (None si está vacía)."""
        if self.cantidad == 0:
            return None
        return self.datos[0]

    def buscar(self, numero, mostrar_recorrido=False):
        """Búsqueda lineal del frente al final. Retorna la posición o -1.
        Con mostrar_recorrido=True imprime los pasajeros que va revisando."""
        for i in range(self.cantidad):
            if mostrar_recorrido:
                if i == 0:
                    print("  Revisó: ", end="")
                else:
                    print(" → ", end="")
                print(self.datos[i].nombre, end="")
            if self.datos[i].numero == numero:
                if mostrar_recorrido:
                    print()
                return i
        if mostrar_recorrido and self.cantidad > 0:
            print()
        return -1

    def modificar(self, numero, nuevo_destino, nuevo_asiento):
        pos = self.buscar(numero)
        if pos == -1:
            return False
        self.datos[pos].destino = nuevo_destino
        self.datos[pos].asiento = nuevo_asiento
        return True

    def eliminar_por_numero(self, numero):
        """No se puede sacar del medio: la fila da una vuelta completa.
        Se desencola cantidad veces; el buscado no se vuelve a encolar."""
        if self.buscar(numero) == -1:
            return False
        total = self.cantidad
        for i in range(total):
            pasajero = self.desencolar()
            if pasajero.numero != numero:
                self.encolar(pasajero)
        return True

    def copiar(self):
        """Nueva cola; encola del frente al final."""
        nueva = MiCola(self.capacidad)
        for i in range(self.cantidad):
            nueva.encolar(self.datos[i])
        return nueva

    def longitud(self):
        return self.cantidad

    def esta_vacia(self):
        return self.cantidad == 0
